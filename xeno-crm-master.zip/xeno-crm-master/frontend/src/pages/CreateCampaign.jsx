import { useState, useEffect } from "react";
import axios from "../api/axios";
import { useNavigate } from "react-router-dom";

const CreateCampaign = () => {
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    recipientIds: [],
  });
  const [customers, setCustomers] = useState([]);
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch customers on mount
    const fetchCustomers = async () => {
      try {
        const response = await axios.get("/customers");
        setCustomers(response.data);
      } catch (err) {
        setError("Failed to load customers. Please refresh the page.");
        console.error("Customer fetch error:", err);
      }
    };
    fetchCustomers();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleRecipientToggle = (customerId) => {
    setFormData((prev) => ({
      ...prev,
      recipientIds: prev.recipientIds.includes(customerId)
        ? prev.recipientIds.filter((id) => id !== customerId)
        : [...prev.recipientIds, customerId],
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!formData.title.trim() || !formData.content.trim()) {
      setError("Title and content are required");
      return;
    }

    if (formData.recipientIds.length === 0) {
      setError("Please select at least one recipient");
      return;
    }

    setIsSubmitting(true);
    try {
      await axios.post(
        "/campaigns",
        {
          title: formData.title.trim(),
          content: formData.content.trim(),
          recipientIds: formData.recipientIds,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      navigate("/campaigns");
    } catch (err) {
      const errorMessage =
        err.response?.data?.message || "Failed to create campaign";
      setError(errorMessage);
      console.error("Campaign creation error:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-4 md:p-6">
      <h1 className="text-2xl font-bold mb-6">Create New Campaign</h1>

      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded">{error}</div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <div>
          <label htmlFor="title" className="block mb-1 font-medium">
            Campaign Title *
          </label>
          <input
            id="title"
            type="text"
            name="title"
            value={formData.title}
            onChange={handleInputChange}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>

        <div>
          <label htmlFor="content" className="block mb-1 font-medium">
            Campaign Content *
          </label>
          <textarea
            id="content"
            name="content"
            value={formData.content}
            onChange={handleInputChange}
            className="w-full p-2 border rounded min-h-[150px] focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>

        <div className="border rounded p-4">
          <h2 className="font-medium mb-3">Select Recipients *</h2>
          {customers.length === 0 ? (
            <p className="text-gray-500">Loading customers...</p>
          ) : (
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {customers.map((customer) => (
                <label
                  key={customer._id}
                  className="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={formData.recipientIds.includes(customer._id)}
                    onChange={() => handleRecipientToggle(customer._id)}
                    className="rounded text-blue-600"
                  />
                  <span>
                    {customer.name}{" "}
                    <span className="text-gray-500">({customer.email})</span>
                  </span>
                </label>
              ))}
            </div>
          )}
        </div>

        <div className="flex justify-end space-x-3 pt-2">
          <button
            type="button"
            onClick={() => navigate("/campaigns")}
            className="px-4 py-2 border rounded hover:bg-gray-50"
            disabled={isSubmitting}
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-blue-400"
          >
            {isSubmitting ? "Creating..." : "Create Campaign"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateCampaign;
