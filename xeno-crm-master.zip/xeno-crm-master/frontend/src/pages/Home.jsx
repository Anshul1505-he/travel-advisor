import { Link } from "react-router-dom";
import useStore from "../stores/useStores"
const Home = () => {
  const token = useStore((state) => state.token);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded shadow-md max-w-xl w-full text-center">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">
          Welcome to AI CRM
        </h1>
        <p className="text-gray-600 mb-6">
          Manage your customers, create campaigns, and get AI-driven insights.
        </p>

        <div className="flex flex-col md:flex-row justify-center gap-4">
          <Link
            to="/customers"
            className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded"
          >
            View Customers
          </Link>
          <Link
            to="/campaigns"
            className="bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded"
          >
            View Campaigns
          </Link>
          <Link
            to="/campaigns/create"
            className="bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded"
          >
            Create Campaign
          </Link>
        </div>

        {!token && (
          <p className="text-sm text-gray-500 mt-6">
            <Link to="/login" className="text-blue-600 hover:underline">Login</Link> or{" "}
            <Link to="/register" className="text-blue-600 hover:underline">Register</Link> to get started.
          </p>
        )}
      </div>
    </div>
  );
};

export default Home;
