import { useEffect, useState } from "react";
import axios from "../api/axios";
import { useNavigate } from "react-router-dom";

const Campaign = () => {
  const [campaigns, setCampaigns] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCampaigns = async () => {
      setError("");
      try {
        const res = await axios.get("/campaigns", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        setCampaigns(res.data);
      } catch (err) {
        console.error(err);
        setError("Failed to load campaigns.");
      } finally {
        setLoading(false);
      }
    };

    fetchCampaigns();
  }, []);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Campaigns</h1>
        <button
          onClick={() => navigate("/create-campaign")}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          + New Campaign
        </button>
      </div>

      {loading && <p>Loading campaigns...</p>}

      {error && (
        <div className="bg-red-100 text-red-700 p-2 rounded mb-4">{error}</div>
      )}

      {campaigns.length === 0 && !loading ? (
        <p className="text-gray-600">No campaigns found.</p>
      ) : (
        <div className="space-y-4">
          {campaigns.map((campaign) => (
            <div
              key={campaign._id}
              className="border p-4 rounded hover:shadow transition"
            >
              <h2 className="text-xl font-semibold text-blue-700">
                {campaign.title}
              </h2>
              <p className="text-gray-800 mt-2">{campaign.content}</p>
              <div className="text-sm text-gray-500 mt-3">
                {campaign.recipientIds?.length || 0} recipients •{" "}
                {new Date(campaign.createdAt).toLocaleString()}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Campaign;
