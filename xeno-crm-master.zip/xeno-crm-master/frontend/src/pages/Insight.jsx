import { useEffect, useState } from "react";
import axios from "../api/axios";

const Insight = () => {
  const [insights, setInsights] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInsights = async () => {
      setError("");
      try {
        const res = await axios.get("/insights", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        setInsights(res.data);
      } catch (err) {
        console.error(err);
        setError("Failed to load insights.");
      } finally {
        setLoading(false);
      }
    };

    fetchInsights();
  }, []);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Insights Dashboard</h1>

      {loading && <p>Loading insights...</p>}

      {error && (
        <div className="bg-red-100 text-red-700 p-2 rounded mb-4">{error}</div>
      )}

      {insights && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-blue-100 text-blue-800 p-4 rounded">
            <h2 className="font-semibold">Total Customers</h2>
            <p className="text-2xl">{insights.totalCustomers}</p>
          </div>
          <div className="bg-green-100 text-green-800 p-4 rounded">
            <h2 className="font-semibold">Total Campaigns</h2>
            <p className="text-2xl">{insights.totalCampaigns}</p>
          </div>
          <div className="bg-purple-100 text-purple-800 p-4 rounded">
            <h2 className="font-semibold">Messages Sent</h2>
            <p className="text-2xl">{insights.totalMessagesSent}</p>
          </div>
        </div>
      )}

      {insights?.engagement && (
        <div>
          <h2 className="text-lg font-semibold mb-2">Engagement Overview</h2>
          <ul className="space-y-2">
            {insights.engagement.map((entry, index) => (
              <li
                key={index}
                className="flex items-center justify-between bg-gray-50 p-3 rounded border"
              >
                <span>{entry.customerName}</span>
                <span className="text-sm text-gray-600">
                  {entry.messagesSent} messages sent
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Insight;
