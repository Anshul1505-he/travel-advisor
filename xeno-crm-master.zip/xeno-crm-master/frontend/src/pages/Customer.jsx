import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "../api/axios";
import useStore from "../stores/useStores";

const Customers = () => {
  const { customers, setCustomers } = useStore();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const res = await axios.get("/customers", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        setCustomers(res.data);
      } catch (err) {
        console.error(err);
        setError("Failed to fetch customers.");
      } finally {
        setLoading(false);
      }
    };

    fetchCustomers();
  }, [setCustomers]);

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Customers</h1>
        <Link
          to="/customers/create"
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          + Add Customer
        </Link>
      </div>

      {loading ? (
        <p className="text-gray-600">Loading customers...</p>
      ) : error ? (
        <p className="text-red-500">{error}</p>
      ) : customers.length === 0 ? (
        <p className="text-gray-500">No customers found.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {customers.map((customer) => (
            <div
              key={customer._id}
              className="border rounded p-4 shadow hover:shadow-md transition"
            >
              <h2 className="text-lg font-semibold text-gray-800">
                {customer.name}
              </h2>
              <p className="text-gray-600">{customer.email}</p>
              <p className="text-gray-500 text-sm mt-1">{customer.tags?.join(", ")}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Customers;
