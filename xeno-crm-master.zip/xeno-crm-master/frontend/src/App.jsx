import { useEffect } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import Navbar from './components/Navbar';

import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Campaigns from './pages/Campaign';
import CreateCampaign from './pages/CreateCampaign';
import Customers from './pages/Customer';
import CreateCustomer from './pages/CreateCustomer';
import Insights from './pages/Insight';

import useStore from './stores/useStores';

function App() {
  const token = useStore(state => state.token);
  const navigate = useNavigate();

  useEffect(() => {
    // Optional: Redirect unauthenticated users from protected routes
    const protectedRoutes = ['/campaigns', '/campaigns/create', '/customers', '/customers/create', '/insights'];
    const currentPath = window.location.pathname;

    if (!token && protectedRoutes.includes(currentPath)) {
      navigate('/login');
    }
  }, [token, navigate]);

  return (
    <div className="min-h-screen font-sans bg-gray-50">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/campaigns" element={<Campaigns />} />
        <Route path="/campaigns/create" element={<CreateCampaign />} />
        <Route path="/customers" element={<Customers />} />
        <Route path="/customers/create" element={<CreateCustomer />} />
        <Route path="/insights" element={<Insights />} />
      </Routes>
    </div>
  );
}

export default App;
