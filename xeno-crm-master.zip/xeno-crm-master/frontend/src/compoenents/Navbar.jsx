import { Link, useNavigate } from 'react-router-dom';
import useStore from '../stores/useStores';

const Navbar = () => {
  const token = useStore((state) => state.token);
  const logout = useStore((state) => state.logout);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout(); // Clears token from Zustand and localStorage
    navigate('/login');
  };

  return (
    <nav className="bg-white shadow px-4 py-3 flex justify-between items-center">
      <Link to="/" className="text-xl font-bold text-blue-600">
        AI CRM
      </Link>

      <div className="flex space-x-4 items-center">
        {token ? (
          <>
            <Link to="/campaigns" className="hover:text-blue-600 font-medium">
              Campaigns
            </Link>
            <Link to="/customers" className="hover:text-blue-600 font-medium">
              Customers
            </Link>
            <Link to="/insights" className="hover:text-blue-600 font-medium">
              Insights
            </Link>
            <button
              onClick={handleLogout}
              className="ml-2 px-4 py-1 bg-red-500 text-white rounded hover:bg-red-600"
            >
              Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login" className="hover:text-blue-600 font-medium">
              Login
            </Link>
            <Link to="/register" className="hover:text-blue-600 font-medium">
              Register
            </Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
