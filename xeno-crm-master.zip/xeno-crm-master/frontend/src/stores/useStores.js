import { create } from 'zustand';
import axios from '../api/axios';

const useStore = create((set, get) => ({
  // Auth
  token: localStorage.getItem('token') || '',
  setToken: (token) => {
    localStorage.setItem('token', token);
    set({ token });
  },
  logout: () => {
    localStorage.removeItem('token');
    set({ token: '' });
  },

  // Customers
  customers: [],
  fetchCustomers: async () => {
    try {
      const response = await axios.get('/customers', {
        headers: {
          Authorization: `Bearer ${get().token}`
        }
      });
      set({ customers: response.data });
    } catch (err) {
      console.error('Failed to fetch customers:', err);
    }
  },
  addCustomer: async (data) => {
    try {
      const response = await axios.post('/customers', data, {
        headers: {
          Authorization: `Bearer ${get().token}`
        }
      });
      set((state) => ({
        customers: [...state.customers, response.data]
      }));
    } catch (err) {
      console.error('Failed to add customer:', err);
    }
  },

  // Campaigns
  campaigns: [],
  fetchCampaigns: async () => {
    try {
      const response = await axios.get('/campaigns', {
        headers: {
          Authorization: `Bearer ${get().token}`
        }
      });
      set({ campaigns: response.data });
    } catch (err) {
      console.error('Failed to fetch campaigns:', err);
    }
  },
  createCampaign: async (data) => {
    try {
      const response = await axios.post('/campaigns', data, {
        headers: {
          Authorization: `Bearer ${get().token}`
        }
      });
      set((state) => ({
        campaigns: [...state.campaigns, response.data]
      }));
      return true;
    } catch (err) {
      console.error('Failed to create campaign:', err);
      return false;
    }
  }
}));

export default useStore;
