import express from 'express';
import { getInsights, createInsight } from '../controllers/insightController.js';
const router = express.Router();

router.get('/', getInsights);
router.post('/', createInsight);

export default router;
