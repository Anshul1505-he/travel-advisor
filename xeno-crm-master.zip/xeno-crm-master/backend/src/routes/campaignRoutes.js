import express from 'express';
import { createCampaign, getCampaigns } from '../controllers/campaignController.js';
import { authenticate } from '../middleware/authMiddleware.js';
const router = express.Router();

// All routes in this file will require auth
router.use(authenticate);

router.post('/', createCampaign);
router.get('/', getCampaigns);

export default router;