import mongoose from 'mongoose';

const customerSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  location: String,
  tags: [String],
  campaigns: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Campaign' }],
});

export default mongoose.model('Customer', customerSchema);
