import mongoose from 'mongoose';

const insightSchema = new mongoose.Schema({
  summary: String,
  dataPoints: Object,
  createdAt: { type: Date, default: Date.now },
  customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer' },
});

export default mongoose.model('Insight', insightSchema);
