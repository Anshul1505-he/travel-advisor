import mongoose from 'mongoose';

const campaignSchema = new mongoose.Schema({
  title: String,
  content: String,
  summary: String,
  suggestedMessage: String,
  autoTags: [String],
  scheduledTime: Date,
  recipients: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Customer' }],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.model('Campaign', campaignSchema);
