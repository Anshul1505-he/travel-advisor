import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import connectDB from './utils/db.js';
import authRoutes from './routes/authRoutes.js';
import customerRoutes from './routes/customerRoutes.js';
import campaignRoutes from './routes/campaignRoutes.js';
import insightRoutes from './routes/insightRoutes.js';
import { authenticate } from './middleware/authMiddleware.js';

dotenv.config();
const app = express();
connectDB();
app.use(cors());
app.use(express.json());
// Apply authenticate middleware to all other routes
app.use(authenticate); 
// This will protect all routes below
app.use((err, req, res, next) => {
  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
  next(err);
});

app.use('/api/auth', authRoutes);
app.use('/api/customers', customerRoutes);
app.use('/api/campaigns', campaignRoutes);
app.use('/api/insights', insightRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
