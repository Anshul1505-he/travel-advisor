import Campaign from '../models/Campaign.js';
import Customer from '../models/Customer.js';
import { sendCampaign } from '../utils/mailer.js';
import { generateSummary, suggestMessage, autoTag, smartSchedule } from '../utils/aiHelper.js';

export const createCampaign = async (req, res) => {
  try {
    const { title, content, recipientIds } = req.body;

    // Await AI helpers to get real data
    const summary = await generateSummary(content);
    const suggestedMessage = await suggestMessage(content);
    const autoTags = await autoTag(content);
    const scheduledTime = await smartSchedule();

    const campaign = await Campaign.create({
      title,
      content,
      summary,
      suggestedMessage,
      autoTags,
      scheduledTime,
      recipients: recipientIds,
      createdBy: req.user.id,
    });

    await Customer.updateMany(
      { _id: { $in: recipientIds } },
      { $push: { campaigns: campaign._id } }
    );

    const recipients = await Customer.find({ _id: { $in: recipientIds } });
    await sendCampaign({
      title,
      content,
      recipients: recipients.map(c => c.email),
    });

    res.status(201).json({ message: 'Campaign created and scheduled', campaign });
  } catch (error) {
    res.status(500).json({ message: 'Error creating campaign', error });
  }
};

export const getCampaigns = async (req, res) => {
  try {
    const campaigns = await Campaign.find()
      .populate('recipients', 'name email')
      .populate('createdBy', 'name email');
    res.json(campaigns);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching campaigns', error });
  }
};
