import Insight from '../models/Insight.js';

export const getInsights = async (req, res) => {
  const insights = await Insight.find().populate('customer', 'name email');
  res.json(insights);
};

export const createInsight = async (req, res) => {
  const insight = await Insight.create(req.body);
  res.status(201).json(insight);
};