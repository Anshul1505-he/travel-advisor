import Customer from '../models/Customer.js';

export const getCustomers = async (req, res) => {
  try {
    const { tag, location } = req.query;
    const filters = {};
    if (tag) filters.tags = tag;
    if (location) filters.location = location;
    const customers = await Customer.find(filters);
    res.json(customers);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching customers', error });
  }
};

export const createCustomer = async (req, res) => {
  try {
    const customer = await Customer.create(req.body);
    res.status(201).json(customer);
  } catch (error) {
    res.status(500).json({ message: 'Error creating customer', error });
  }
};
