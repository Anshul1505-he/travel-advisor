import OpenAI from 'openai';
import dotenv from 'dotenv';
dotenv.config();


// Don't hardcode your API key; use environment variables instead
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export const generateSummary = async (content) => {
  const response = await openai.chat.completions.create({
    model: 'gpt-4.1', // or 'gpt-3.5-turbo' if needed
    messages: [
      { role: 'system', content: 'You are an assistant that summarizes campaign messages.' },
      { role: 'user', content },
    ],
  });
  return response.choices[0].message.content.trim();
};

export const suggestMessage = async (content) => {
  const response = await openai.chat.completions.create({
    model: 'gpt-4.1',
    messages: [
      { role: 'system', content: 'You are an assistant that improves campaign messages for customer engagement.' },
      { role: 'user', content },
    ],
  });
  return response.choices[0].message.content.trim();
};

export const autoTag = async (content) => {
  const response = await openai.chat.completions.create({
    model: 'gpt-4.1',
    messages: [
      { role: 'system', content: 'Generate 3 to 5 relevant tags from this content, comma-separated.' },
      { role: 'user', content },
    ],
  });
  return response.choices[0].message.content.trim().split(',').map(tag => tag.trim());
};

export const smartSchedule = async () => {
  const now = new Date();
  return new Date(now.getTime() + 60 * 60 * 1000); // 1 hour from now
};
