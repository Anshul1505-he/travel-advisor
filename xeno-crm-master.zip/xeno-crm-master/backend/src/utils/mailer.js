import nodemailer from 'nodemailer';

export const sendCampaign = async ({ title, content, recipients }) => {
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });

  for (const recipient of recipients) {
    await transporter.sendMail({
      from: `Mini CRM <${process.env.EMAIL_USER}>`,
      to: recipient,
      subject: title,
      html: content,
    });
  }
};
